### Olá, sou o Alê! 🦄

##

- 👾 Estudante de Sistemas de Informação

<div align="center">
  <a href="https://github.com/allecporfirio">
  <img height="180em" src="https://github-readme-stats.vercel.app/api?username=allecporfirio&show_icons=true&theme=tokyonight&include_all_commits=true&count_private=true"/>
  <img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=allecporfirio&layout=compact&langs_count=7&theme=tokyonight"/>
</div>

  ##
  
  <div>
      <a href="https://www.linkedin.com/in/alessandro-porfírio-124790184/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a>
   
  ![Snake animation](https://github.com/allecporfirio/allecporfirio/blob/output/github-contribution-grid-snake.svg)


  </div>

  
  
  ![c633c20ede82f0e0ced7d570dbe3a1f3](https://user-images.githubusercontent.com/70382532/138322189-2db8df52-9dcb-40a0-88a8-c365466bd33d.gif)
